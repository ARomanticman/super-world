package uyun.bird.notify.third.util;

import cn.hutool.core.date.DateUtil;
import cn.hutool.core.lang.Snowflake;
import cn.hutool.core.util.RandomUtil;
import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.XMLWriter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import uyun.bird.notify.third.enums.SmsServiceType;
import uyun.bird.notify.third.enums.SmsXmlType;

import java.io.IOException;
import java.io.StringWriter;
import java.util.Date;
import java.util.Map;

/**
 * 短信发送公用类
 *
 * @author Jerry
 * @version 2019-04-19
 */
public class ThirdSmsUtils {

    private static final Logger LOGGER = LoggerFactory.getLogger(ThirdSmsUtils.class);

    private static final String SYS_REQ_SEC_ID = "00000G";
    private static final String SYS_SND_SEC_ID = "00000G";
    private static final String SYS_CHNL_TPCD = "HG";
    private static final String SYS_CHLD_CHNL = "02";
    private static final String MSG_CMPT_ID = "A3111";
//    private static final String MSG_SMS_TP_ID = "TA223_YZM";
    private static final String MSG_SMS_TP_ID = "TA223_DZ";
    private static final String MSG_SMS_SNDR = "999999999";

    public static final String MESSAGE_CONTENT = "message_content";
    public static final String MESSAGE_TRACE_NO = "message_trace_no";
    public static final String MESSAGE_VERIFICATION_CODE = "message_verification_code";

    public static String buildSmsXmlMessage(String phone, Map<String, Object> message, SmsServiceType serviceType) {
        String serviceId;
        switch (serviceType) {
            case SEND_SMS_VERIFICATION_CODE:
                serviceId = "ZFUSR0301";
                break;
            case VERIFY_SMS_CODE:
                serviceId = "ZFUSR0302";
                break;
            case SEND_TXT_MESSAGE:
                serviceId = "ZFUSR0303";
                break;
            default:
                serviceId = "ZFUSR0303";
                break;
        }

        Document doc = DocumentHelper.createDocument();
        Element txRoot = doc.addElement("TX");

        Element txHeader = txRoot.addElement("TX_HEADER");
        txHeader.addElement(SmsXmlType.SYS_HDR_LEN.name());
        txHeader.addElement(SmsXmlType.SYS_PKG_VRSN.name()).addText("01");
        txHeader.addElement(SmsXmlType.SYS_TTL_LEN.name());
        txHeader.addElement(SmsXmlType.SYS_REQ_SEC_ID.name()).addText(SYS_REQ_SEC_ID);
        txHeader.addElement(SmsXmlType.SYS_SND_SEC_ID.name()).addText(SYS_SND_SEC_ID);

        txHeader.addElement(SmsXmlType.SYS_TX_CODE.name()).addText(serviceId);
        txHeader.addElement(SmsXmlType.SYS_TX_TYPE.name()).addText("020000");
        txHeader.addElement(SmsXmlType.SYS_RESERVED.name()).addText("0");
        txHeader.addElement(SmsXmlType.SYS_EVT_TRACE_ID.name()).addText(createTraceId());
        txHeader.addElement(SmsXmlType.SYS_SND_SERIAL_NO.name()).addText("0000000000");
        txHeader.addElement(SmsXmlType.SYS_PKG_TYPE.name()).addText("1");
        txHeader.addElement(SmsXmlType.SYS_MSG_LEN.name());
        txHeader.addElement(SmsXmlType.SYS_IS_ENCRYPTED.name()).addText("0");
        txHeader.addElement(SmsXmlType.SYS_ENCRYPT_TYPE.name()).addText("3");
        txHeader.addElement(SmsXmlType.SYS_COMPRESS_TYPE.name()).addText("0");
        txHeader.addElement(SmsXmlType.SYS_EMB_MSG_LEN.name()).addText("");
        txHeader.addElement(SmsXmlType.SYS_REQ_TIME.name()).addText(DateUtil.format(new Date(), "yyyyMMddHHmmssSSS"));
        txHeader.addElement(SmsXmlType.SYS_TIME_LEFT.name()).addText("000500000");
        txHeader.addElement(SmsXmlType.SYS_PKG_STS_TYPE.name()).addText("00");
        txHeader.addElement(SmsXmlType.SYS_CHNL_TPCD.name()).addText(SYS_CHNL_TPCD);
        txHeader.addElement(SmsXmlType.SYS_CHLD_CHNL.name()).addText(SYS_CHLD_CHNL);
        txHeader.addElement(SmsXmlType.SYS_DEVICE_TAG.name());

        Element txBody = txRoot.addElement("TX_BODY");
        Element txCom1 = txBody.addElement("COMMON").addElement("COM1");
        txCom1.addElement(SmsXmlType.TXN_INSID.name()).addText("130629508");
        txCom1.addElement(SmsXmlType.TXN_ITT_CHNL_ID.name()).addText("9999");
        txCom1.addElement(SmsXmlType.TXN_ITT_CHNL_CGY_CODE.name()).addText("99999999");
        txCom1.addElement(SmsXmlType.TXN_DT.name()).addText(DateUtil.format(new Date(), "yyyyMMdd"));
        txCom1.addElement(SmsXmlType.TXN_TM.name()).addText(DateUtil.format(new Date(), "HHmmss"));
        txCom1.addElement(SmsXmlType.TXN_STFF_ID.name()).addText("00310599");
        txCom1.addElement(SmsXmlType.MULTI_TENANCY_ID.name()).addText("CN000");
        txCom1.addElement(SmsXmlType.LNG_ID.name()).addText("zh-cn");

        Element txEntity = txBody.addElement("ENTITY");
        if (serviceType == SmsServiceType.SEND_SMS_VERIFICATION_CODE) {
            txEntity.addElement(SmsXmlType.MblPh_No.name()).addText("<![CDATA[" + phone + "]]>");
            txEntity.addElement(SmsXmlType.SMS_Tpl_Cntnt.name()).addText("<![CDATA[" + message.get(MESSAGE_CONTENT) + "]]>");
            txEntity.addElement(SmsXmlType.MSG_CMPT_ID.name()).addText("<![CDATA[" + MSG_CMPT_ID + "]]>");
            txEntity.addElement(SmsXmlType.MSG_SMS_TP_ID.name()).addText("<![CDATA[" + MSG_SMS_TP_ID + "]]>");
            txEntity.addElement(SmsXmlType.MSG_SMS_SNDR.name()).addText("<![CDATA[" + MSG_SMS_SNDR + "]]>");
        } else if (serviceType == SmsServiceType.VERIFY_SMS_CODE) {
            if (message.get(MESSAGE_TRACE_NO) == null || message.get(MESSAGE_VERIFICATION_CODE) == null) {
                return null;
            }

            txEntity.addElement(SmsXmlType.MblPh_No.name()).addText("<![CDATA[" + phone + "]]>");
            txEntity.addElement(SmsXmlType.Ori_TrcNo.name()).addText("<![CDATA[" + message.get(MESSAGE_TRACE_NO) + "]]>");
            txEntity.addElement(SmsXmlType.SMS_Vld_CD.name()).addText("<![CDATA[" + message.get(MESSAGE_VERIFICATION_CODE) + "]]>");
        } else {
            txEntity.addElement(SmsXmlType.MSG_CMPT_ID.name()).addText("<![CDATA[" + MSG_CMPT_ID + "]]>"); //统一通信组件接入编号，必填
            txEntity.addElement(SmsXmlType.MSG_SMS_TP_ID.name()).addText("<![CDATA[" + MSG_SMS_TP_ID + "]]>");   //短信类型编码，必填
            txEntity.addElement(SmsXmlType.MSG_SMS_CODE_FMT.name()).addText("15"); //消息编码格式，必填
            txEntity.addElement(SmsXmlType.MSG_SMS_SND_TM.name());
            txEntity.addElement(SmsXmlType.MSG_SMS_VLD_TM.name());
            txEntity.addElement(SmsXmlType.MSG_SMS_MBLPH_NO.name()).addText("<![CDATA[" + phone + "]]>"); //手机号码
            txEntity.addElement(SmsXmlType.MSG_SMS_CNTNT_LEN.name()).addText("128"); //信息内容长度
            txEntity.addElement(SmsXmlType.MSG_SMS_CNTNT.name()).addText("<![CDATA[" + message.get(MESSAGE_CONTENT) + "]]>"); //短信息的内容
            txEntity.addElement(SmsXmlType.MSG_SMS_REALTM_IND.name()).addText(""); //实时通知标志
            txEntity.addElement(SmsXmlType.MSG_SMS_RECPT.name()).addText("0"); //收条标志
            txEntity.addElement(SmsXmlType.MSG_SMS_SNDR.name()).addText("<![CDATA[" + MSG_SMS_SNDR + "]]>"); //短信归属信息
            txEntity.addElement(SmsXmlType.MSG_SMS_NO.name());
            txEntity.addElement(SmsXmlType.MSG_SMS_FEE.name());
            txEntity.addElement(SmsXmlType.MSG_INF.name());
        }

        txRoot.addElement("TX_EMB");
        return formatXml(doc, "UTF-8", false);
    }

    /**
     * 格式化XML文档
     *
     * @param document     xml文档
     * @param charset      字符串的编码
     * @param isEscapeText 是否对属性和元素值进行转移
     * @return 格式化后XML字符串
     */
    public static String formatXml(Document document, String charset, boolean isEscapeText) {
        OutputFormat format = OutputFormat.createCompactFormat();
        format.setEncoding(charset);
        StringWriter sw = new StringWriter();
        XMLWriter xw = new XMLWriter(sw, format);
        xw.setEscapeText(isEscapeText);
        try {
            xw.write(document);
            xw.flush();
            xw.close();
        } catch (IOException e) {
            LOGGER.error("格式化XML文档发生异常，请检查！");
            e.printStackTrace();
        }
        return sw.toString();
    }

    private static String createTraceId() {
        Snowflake snowflake = new Snowflake(0, 0);
        return snowflake.nextIdStr() + RandomUtil.randomNumbers(6);
    }

}
