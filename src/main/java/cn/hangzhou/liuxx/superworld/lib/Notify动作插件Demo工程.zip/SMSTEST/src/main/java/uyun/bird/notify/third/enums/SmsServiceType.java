package uyun.bird.notify.third.enums;

/**
 * 短信发送类型
 *
 * @author Jerry
 * @version 2019-04-21
 */
public enum SmsServiceType {

    /**
     * 发送短信验证码
     */
    SEND_SMS_VERIFICATION_CODE(),

    /**
     * 验证码短信验证码
     */
    VERIFY_SMS_CODE(),

    /**
     * 发送普通短信
     */
    SEND_TXT_MESSAGE();

}
