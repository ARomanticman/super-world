package uyun.bird.notify.third.enums;

/**
 * 短信报文内容
 *
 * @author Jerry
 * @version 2019-04-11
 */
public enum SmsXmlType {

    /**
     * 安全报文
     */
    SEC_ERROR_CODE("错误码"),
    SEC_IS_MAC("是否MAC"),
    SEC_IS_CONTEXT("是否校验上下文"),
    SEC_IS_ENC("是否加密"),
    SEC_MAC("报文MAC"),
    SEC_CONTEXT("安全上下文"),
    SEC_ID1("本安全节点号"),
    SEC_ID2("目标安全节点号"),
    SEC_TRACE_ID("交易跟踪号"),
    SEC_TX_CODE("服务名"),
    SEC_TX_TYPE("服务种类"),
    SEC_LEN("交易报文长度"),

    /**
     * 交易请求报文头
     */
    SYS_HDR_LEN("报文头长度"),
    SYS_PKG_VRSN("报文格式版本号"),
    SYS_TTL_LEN("报文总长度"),
    SYS_REQ_SEC_ID("发起方安全节点编号"),
    SYS_SND_SEC_ID("发送方安全节点编号"),
    SYS_TX_CODE("服务名"),
    SYS_TX_VRSN("服务版本号"),
    SYS_TX_TYPE("服务种类"),
    SYS_RESERVED("预留"),
    SYS_EVT_TRACE_ID("全局事件跟踪号"),
    SYS_SND_SERIAL_NO("子交易序号"),
    SYS_PKG_TYPE("应用报文格式类型"),
    SYS_MSG_LEN("应用报文长度"),
    SYS_IS_ENCRYPTED("应用报文是否加密"),
    SYS_ENCRYPT_TYPE("应用报文加密方式"),
    SYS_COMPRESS_TYPE("应用报文压缩方式"),
    SYS_EMB_MSG_LEN("捎带报文长度"),
    SYS_REQ_TIME("发起方交易时间"),
    SYS_TIME_LEFT("交易剩余处理时间"),
    SYS_PKG_STS_TYPE("报文状态类型"),
    SYS_CHNL_TPCD("渠道编号"),
    SYS_CHLD_CHNL("子渠道类型"),
    SYS_DEVICE_TAG("设备信息"),

    /**
     * 交易请求报文体-通用域
     */
    TXN_INSID("NA"),
    TXN_ITT_CHNL_ID("NA"),
    TXN_ITT_CHNL_CGY_CODE("NA"),
    TXN_DT("NA"),
    TXN_TM("NA"),
    TXN_STFF_ID("NA"),
    MULTI_TENANCY_ID("NA"),
    LNG_ID("NA"),

    /**
     * 交易请求报文体-实体域
     */
    MSG_CMPT_ID("统一通信组件接入编号"),
    MSG_SMS_TP_ID("短信类型编码"),
    MSG_SMS_CODE_FMT("消息编码格式"),
    MSG_SMS_SND_TM("指定发送时间"),
    MSG_SMS_VLD_TM("有效时间"),
    MSG_SMS_MBLPH_NO("手机号码"),
    MSG_SMS_CNTNT_LEN("信息内容长度"),
    MSG_SMS_CNTNT("短消息的内容"),
    MSG_SMS_REALTM_IND("实时通知标志"),
    MSG_SMS_RECPT("收条标志"),
    MSG_SMS_SNDR("短信归属信息"),
    MSG_SMS_NO("长号码，可空"),
    MSG_SMS_FEE("计费标志，可空"),
    MSG_INF("保留，可空"),

    MblPh_No("短信验证码，手机号"),
    SMS_Tpl_Cntnt("短信验证码，短信模版内容"),
    SMS_Vld_CD("短信验证码，短信验证码"),
    Ori_TrcNo("短信验证码，愿流水号"),

    /**
     * 交易应答报文头,只列出需要的部分
     */
    SYS_TX_STATUS("服务响应状态"),
    SYS_RESP_DESC("服务响应描述");

    String description;

    SmsXmlType(String description) {
        this.description = description;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
