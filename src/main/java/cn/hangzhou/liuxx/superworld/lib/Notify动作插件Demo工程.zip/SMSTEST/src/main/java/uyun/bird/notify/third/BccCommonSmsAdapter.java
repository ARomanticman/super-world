package uyun.bird.notify.third;

import cn.hutool.core.util.StrUtil;
import cn.hutool.http.HttpRequest;
import cn.hutool.http.HttpResponse;
import cn.hutool.json.JSONUtil;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import uyun.bird.notify.api.*;
import uyun.bird.notify.third.enums.SmsServiceType;
import uyun.bird.notify.third.enums.SmsXmlType;
import uyun.bird.notify.third.util.ThirdSmsUtils;

import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;

/**
 * 短信发送实现类（新版短信发送，包含频率控制）
 *
 * @author Jerry
 * @version 2019-04-19
 */
@Component
public class BccCommonSmsAdapter implements NotifyServiceCommonSender {

    private static Logger LOGGER = LoggerFactory.getLogger(BccCommonSmsAdapter.class);

    private static String url;

    @Value("${notify.3rd.sms.url:http://128.196.218.1:8101/zfusr/httpService}")
    public void setUrl(String defaultUrl) {
        url = defaultUrl;
    }

    @Override
    public SendResult sendMessage(MessageEntity messageEntity) throws NotifyException {
        SendResult sendResult = new SendResult();

        if (messageEntity.getActionCode().equals("ZFUSR0302")) {

            LOGGER.info("[SEND SMS] verifySmsCode start ... [{}], [{}]", messageEntity.getReceivers(), messageEntity.getExtend());
            String phone = messageEntity.getReceivers().get(0);

            if (StrUtil.isBlank(messageEntity.getExtend())) {
                LOGGER.error("[SEND SMS] extend is null ! phone={}", phone);
                sendResult.setSuccess(false);
                sendResult.setErrorMessage("The parameters are incorrect, please check");
                return sendResult;
            }
            String smsCode = messageEntity.getMessage();
            String traceNo = messageEntity.getExtend();
            Map<String, Object> messageMap = new HashMap<String, Object>();
            messageMap.put(ThirdSmsUtils.MESSAGE_VERIFICATION_CODE, smsCode);
            messageMap.put(ThirdSmsUtils.MESSAGE_TRACE_NO, traceNo);

            if (StrUtil.isBlank(phone) || StrUtil.isBlank(traceNo) || StrUtil.isBlank(smsCode)) {
                LOGGER.error("[SEND SMS] content is null ! phone={}, traceNo={}, smsCode={}", phone, traceNo, smsCode);
                sendResult.setSuccess(false);
                sendResult.setErrorMessage("The parameters are incorrect, please check");
                return sendResult;
            }

            if (!Pattern.matches("\\d{11}", messageEntity.getReceivers().get(0))) {
                LOGGER.error("[SEND SMS] phone({}) is illegal !", messageEntity.getReceivers().get(0));
                sendResult.setSuccess(false);
                sendResult.setErrorMessage("phone is illegal, please check");
                return sendResult;
            }

            String xmlStr = ThirdSmsUtils.buildSmsXmlMessage(phone, messageMap, SmsServiceType.VERIFY_SMS_CODE);
            if (StrUtil.isBlank(xmlStr)) {
                LOGGER.error("[SEND SMS] message({}) is illegal !", JSONUtil.toJsonStr(messageMap));
                sendResult.setSuccess(false);
                sendResult.setErrorMessage("smsCode is error, please check");
                return sendResult;
            }

            LOGGER.info("===================");
            LOGGER.info("url: {}", url);
            LOGGER.info("===================");
            LOGGER.info(xmlStr);
            LOGGER.info("===================");

            HttpResponse response = null;
            try {
                response = HttpRequest.post(url)
                        .body(xmlStr)
                        .timeout(30000)
                        .execute();
            } catch (Exception e) {
                LOGGER.error("send is error, [{}]", e.getMessage());
                sendResult.setSuccess(false);
                sendResult.setErrorMessage(e.getMessage());
                return sendResult;
            }

            String resXml = response.body();
            if (StrUtil.isBlank(resXml)) {
                LOGGER.error("[SEND SMS] response message is null, status={} !", response.getStatus());
                sendResult.setSuccess(false);
                sendResult.setErrorMessage("SMS platform response message is null");
                return sendResult;
            }

            try {
                Document docRes = DocumentHelper.parseText(resXml);

                Element sysTxStatus = docRes.getRootElement().element("TX_HEADER").element(SmsXmlType.SYS_TX_STATUS.name());
                if ("01".equals(sysTxStatus.getTextTrim())) {
                    LOGGER.error("[SEND SMS] send failed, xml is {}", resXml);
                    sendResult.setSuccess(false);
                    return sendResult;
                }

            } catch (DocumentException e) {
                LOGGER.error("[SEND SMS] Error parsing response message ! {}", resXml);
                e.printStackTrace();
                sendResult.setSuccess(false);
                return sendResult;
            }

            LOGGER.info("[SEND SMS] verifySmsCode end ...");
            sendResult.setSuccess(true);
            return sendResult;

        } else {
            LOGGER.info("[SEND SMS] send start ... [{}], [{}], [{}]", messageEntity.getReceivers(), messageEntity.getMessage(), messageEntity.getActionCode());

            boolean result = true;
            Map<String, Object> messageMap = new HashMap<String, Object>();
            messageMap.put(ThirdSmsUtils.MESSAGE_CONTENT, messageEntity.getMessage());
            Map<String, SingleResult> detailMessage = new HashMap<>();

            for (String phone : messageEntity.getReceivers()) {
                if (StrUtil.isBlank(phone)) {
                    LOGGER.error("[SEND SMS] phone is null !");
                    result = false;
                    detailMessage.put(phone, new SingleResult(false, "phone is null"));
                    continue;
                }

                if (!Pattern.matches("\\d{11}", phone)) {
                    LOGGER.error("[SEND SMS] phone({}) is illegal !", phone);
                    result = false;
                    detailMessage.put(phone, new SingleResult(false, "phone is illegal"));
                    continue;
                }

                if (StrUtil.isBlank(messageEntity.getMessage())) {
                    LOGGER.error("[SEND SMS] message is null !");
                    result = false;
                    detailMessage.put(phone, new SingleResult(false, "message is null"));
                    continue;
                }

                if (messageEntity.getActionCode() == null) {
                    LOGGER.error("[SEND SMS] Sms actionCode is null !");
                    result = false;
                    detailMessage.put(phone, new SingleResult(false, "Sms actionCode is null"));
                    continue;
                }
                SmsServiceType type;
                if (messageEntity.getActionCode().equals("ZFUSR0301")) {
                    type = SmsServiceType.SEND_SMS_VERIFICATION_CODE;
                } else {
                    type = SmsServiceType.SEND_TXT_MESSAGE;
                }

                String xmlStr = ThirdSmsUtils.buildSmsXmlMessage(phone, messageMap, type);
                if (StrUtil.isBlank(xmlStr)) {
                    String errorMsg = JSONUtil.toJsonStr(messageMap);
                    LOGGER.error("[SEND SMS] message({}) is illegal !", errorMsg);
                    detailMessage.put(phone, new SingleResult(false, "message is illegal"));
                    result = false;
                    continue;
                }

                LOGGER.info("===================");
                LOGGER.info("url:" + url);
                LOGGER.info("===================");
                LOGGER.info(xmlStr);
                LOGGER.info("===================");

                HttpResponse response = null;
                try {
                    response = HttpRequest.post(url)
                            .body(xmlStr)
                            .timeout(30000)
                            .execute();
                } catch (Exception e) {
                    LOGGER.error("send is error, [{}]", e.getMessage());
                    detailMessage.put(phone, new SingleResult(false, e.getMessage()));
                    result = false;
                    continue;
                }

                String resXml = response.body();
                if (StrUtil.isBlank(resXml)) {
                    LOGGER.error("[SEND SMS] response message is null, status={} !", response.getStatus());
                    result = false;
                    detailMessage.put(phone, new SingleResult(false, "response message is null"));
                    continue;
                }

                try {
                    Document docRes = DocumentHelper.parseText(resXml);

                    Element sysTxStatus = docRes.getRootElement().element("TX_HEADER").element(SmsXmlType.SYS_TX_STATUS.name());
                    if ("01".equals(sysTxStatus.getTextTrim())) {
                        LOGGER.error("[SEND SMS] send failed, xml is {}", resXml);
                        result = false;
                        Element errorMsg = docRes.getRootElement().element("TX_HEADER").element(SmsXmlType.SYS_RESP_DESC.name());
                        detailMessage.put(phone, new SingleResult(false, errorMsg.getTextTrim()));
                        continue;
                    }

                    if (type == SmsServiceType.SEND_SMS_VERIFICATION_CODE) {
                        Element trcNo = docRes.getRootElement().element("TX_BODY").element("ENTITY").element("TrcNo");
                        sendResult.setResultMessage(trcNo.getText());
                    }

                    detailMessage.put(phone, new SingleResult(true, ""));
                } catch (DocumentException e) {
                    LOGGER.error("[SEND SMS] Error parsing response message ! {}", resXml);
                    e.printStackTrace();
                    result = false;
                    detailMessage.put(phone, new SingleResult(false, "Error parsing response message"));
                }
            }

            sendResult.setDetailMessage(detailMessage);
            sendResult.setSuccess(result);
            sendResult.setErrorMessage("");
            LOGGER.info("[SEND SMS] send end ... sendResult={}", JSONUtil.toJsonStr(sendResult));
            return sendResult;
        }
    }

    @Override
    public SendResult sendEmail(EmailEntity emailEntity) throws NotifyException {
        return null;
    }
}
